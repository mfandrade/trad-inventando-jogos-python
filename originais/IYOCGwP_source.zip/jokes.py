print 'What do you get when you cross a snowman with a vampire?' # - Released under the GPL Gnu Public License, Version 3 - http://www.gnu.org/licenses/gpl-3.0.html
raw_input()
print 'Frostbite!'
print
print 'What do dentists call a astronaut\'s cavity?'
raw_input()
print 'A black hole!'
print
print 'Knock knock.'
raw_input()
print "Who's there?"
raw_input()
print 'Interrupting cow.'
raw_input()
print 'Interrupting cow wh',
print 'MOO!'

# This program says hello and asks for my name. - Released under the GPL Gnu Public License, Version 3 - http://www.gnu.org/licenses/gpl-3.0.html
print 'Hello world!'
print 'What is your name?'
myName = raw_input()
print 'It is good to meet you, ' + myName

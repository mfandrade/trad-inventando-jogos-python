# Favorite stuff - Released under the GPL Gnu Public License, Version 3 - http://www.gnu.org/licenses/gpl-3.0.html
print 'Tell me what your favorite color is.'
favoriteColor = raw_input()

print 'Tell me what your favorite animal is.'
favoriteAnimal = raw_input()

print 'Tell me what your favorite food is.'
favoriteFood = raw_input()

# display our favorite stuff
print 'You entered: ' + favoriteFood + ' ' + favoriteAnimal + ' ' + favoriteColor
# print 'Here is a list of your favorite things.'
print 'Color: ' + favoriteColor
print 'Animal: ' + favoriteAnimal
print 'Food: ' + favoriteFood
